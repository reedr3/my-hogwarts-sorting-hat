//'use strict';

module.exports = {
  testHelperFn: function (x) {
    return 3 + x;
  }
};
