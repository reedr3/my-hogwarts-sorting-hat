'use strict';

module.exports = {
    /**
     * When editing your questions pay attention to your punctuation. Make sure you use question marks or periods.
     * Make sure the first answer is the correct one. Set at least ANSWER_COUNT answers, any extras will be shuffled in.
     */
    "QUESTIONS_EN_US" : [
        {
            "Is this a question?": [
                "yes",
                "nope",
                "what",
                "um"
            ]
        },

        {
            "Is this question 2?": [
                "yes",
                "nope",
                "what",
                "um"
            ]
        },

        {
            "Is this question 3?": [
                "yes",
                "nope",
                "what",
                "um"
            ]
        },

        {
            "Is this question 4?": [
                "yes",
                "nope",
                "what",
                "um"
            ]
        },

        {
            "Is this question 5?": [
                "yes",
                "nope",
                "what",
                "um"
            ]
        },

        {
            "Is this question 6?": [
                "yes",
                "nope",
                "what",
                "um"
            ]
        },

        {
            "Is this question 7?": [
                "yes",
                "nope",
                "what",
                "um"
            ]
        }
    ]
};
