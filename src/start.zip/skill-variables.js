module.exports = {

  // TODO
  // create separate file to run actual sorting (you know... the point of all this, lol)
  // extra credit: have it know if it's sorted a student already since it was last restarted so it can ask if want to sort another student or something
  // extra extra credit: have it keep a tally of people's names (or numbers at least) and which houses they were sorted into

  "sortingQuestions": [
    [
      "Which of the following would you most hate people to call you? Ordinary, ignorant, cowardly, or selfish. ",
      "Given the choice, would you rather invent a potion that would guarantee you love, glory, wisdom, or power? ",
      "question one three",
      "question one four"
    ],
    [
      "question two one",
      "question two two",
      "question two three",
      "question two four"
    ],
    [
      "question three one",
      "question three two",
      "question three three",
      "question three four"
    ],
    [
      "question four one",
      "question four two",
      "question four three",
      "question four four"
    ],
    [
      "question five one",
      "question five two",
      "question five three",
      "question five four"
    ],
    [
      "question six one",
      "question six two",
      "question six three",
      "question six four"
    ],
    [
      "question seven one",
      "question seven two",
      "question seven three",
      "question seven four"
    ],
    [
      "Your wishes are important to my decision so if there is a particular house you do not wish to be a part of, I will take that into consideration. Simply say which house you don't want to be in, for example say not Slytherin. Or say any is fine. ",
      "Your wishes are important to my decision so if there is a particular house you do not wish to be a part of, I will take that into consideration. Simply say which house you don't want to be in, for example say not Slytherin. Or say any is fine. ",
      "Your wishes are important to my decision so if there is a particular house you do not wish to be a part of, I will take that into consideration. Simply say which house you don't want to be in, for example say not Slytherin. Or say any is fine. ",
      "Your wishes are important to my decision so if there is a particular house you do not wish to be a part of, I will take that into consideration. Simply say which house you don't want to be in, for example say not Slytherin. Or say any is fine. "
    ]
  ],

  "houseAnswers": {

    "Gryffindor": [
      "cowardly", "glory", "g3", "g4", "g5", "g6", "g7",
      "g8", "g9", "g10", "g11", "g12", "g13", "g14",
      "g15", "g16", "g17", "g18", "g19", "g20", "g21",
      "g22", "g23", "g24", "g25", "g26", "g27", "g28"
    ],

    "Ravenclaw": [
      "ignorant", "wisdom", "r3", "r4", "r5", "g6", "g7",
      "g8", "g9", "g10", "g11", "g12", "g13", "g14",
      "g15", "g16", "g17", "g18", "g19", "g20", "g21",
      "g22", "g23", "g24", "g25", "g26", "g27", "g28"
    ],

    "Hufflepuff": [
      "selfish", "love", "h3", "h4", "h5", "g6", "g7",
      "g8", "g9", "g10", "g11", "g12", "g13", "g14",
      "g15", "g16", "g17", "g18", "g19", "g20", "g21",
      "g22", "g23", "g24", "g25", "g26", "g27", "g28"
    ],

    "Slytherin": [
      "ordinary", "power", "s3", "s4", "s5", "g6", "g7",
      "g8", "g9", "g10", "g11", "g12", "g13", "g14",
      "g15", "g16", "g17", "g18", "g19", "g20", "g21",
      "g22", "g23", "g24", "g25", "g26", "g27", "g28"
    ]
  },

  "houses": [
      "Gryffindor! ",
      "Ravenclaw! ",
      "Hufflepuff! ",
      "Slytherin! "
  ],

  "poems": [
     "You've been sorted into Gryffindor, Where dwell the brave of heart, Their daring, nerve, and chivalry, set Gryffindors apart. ",
     "You've been sorted into Ravenclaw, Since you've a ready mind, Where those of wit and learning, Will always find their kind. ",
     "You've been sorted into Hufflepuff, Where they are just and loyal, Those patient Hufflepuffs are true, and unafraid of toil. Also, Honey badger don't give a shih. ",
     "You've been sorted into Slytherin, Where you'll make your true friends. Those cunning folk use any means, To achieve their ends. "
  ],

  "questions": [
     "For some it is clear where they belong. Others are harder and I need more time to decide. ",
     "Ah yes, you were particularly difficult to sort, but I stand by what I said. ", // could make this more fun/complicated later by creating an attributes variable to store the most recently sorted student's house and say "i stand by what i said, you will do well in __"
     "Witty answer number three. ",
     "Witty answer number four. "
  ],

  "states": {
      STARTMODE: '_STARTMODE',        // prompt user to start with either song or sorting
      SORTINGMODE: '_SORTINGMODE',    // actual sorting questions
      ANNOUNCEMODE: '_ANNOUNCEMODE',  // announce house user was sorted into and offer poem about house
      NAVMODE: '_NAVMODE',            // intermediate/central menu where you can go back to song, sort another user, or ask hat questions
      QUESTIONSMODE: '_QUESTIONSMODE' // offers possible questions the user can ask the hat, then provides answers
  },

  "messages": {
      "welcomeMessage": "Welcome to hogworts! Before you begin your studies you must be sorted into your houses. While here, your house will be like your family. Lets begin! Do you want to hear the sorting song or do you want to skip to the sorting ceremony? Say begin song or say begin sorting. ",
      "repeatWelcomeMessage": "Say begin song or say begin sorting. ",
      "afterSongMessage": "Heed well my words. Would you like to begin the sorting now? Say begin sorting. ",
      "preSortingMessage": "Put me on so I can sort you! ",
      "endOfSortingMessage": "I know just what to do with you! Are you ready to hear your house? Take me off so I can announce your house! Then say ready. ",
      "postSortingMessage": "Better be ",
      "postAnnounceMessage": "Would you like to hear more about your house or continue? Say hear more or say continue. ",
      "continueMessage": "Please say continue. ",
      "navMessage": "Would you like to hear the sorting song again? Or would you like to sort another student? Or would the student just sorted like to ask me some questions? Say begin song, or say sort another student, or say I have a question (and put the hat back on). Or say mischief managed to finish. ",
      "chooseQuestionMessage": "Bee in your bonnet? Which of the following questions would you like to ask? One, did you put me in the right house? Two, why do you take longer to sort some people? Three, third question. Four, fourth question. Say one, two, three, or four to ask your question. ",
      "anotherQuestionMessage": "Do you have another question? ",
      "goodbyeMessage": "Goodbye! ",
      "helpMessage": "I am the sorting hat! I can sing my song for you, or I can ask you questions and sort you into your house, or you can ask me questions after I sort you. ",
      "startOverMessage": "Would you like to start the program over? Say start over. ",
      "unhandleMessage": "Sorry, I didn't catch that. ",
      "sortingHelpMessage": "Say one, two, three, or four to answer. "
  },

  "sortingSongs": [

    "Oh, you may not think I'm pretty, But don't judge on what you see. I'll eat myself if you can find, A smarter hat than me. " +
    "You can keep your bowler's black, Your top hats sleek and tall, For I'm the Hogwarts Sorting Hat, And I can cap them all. " +
    "You might belong in Gryffindor, Where dwell the brave of heart, Their daring, nerve, and chivalry, set Gryffindors apart. " +
    "You might belong in Hufflepuff, Where they are just and loyal, Those patient Hufflepuffs are true, and unafraid of toil. " +
    "Or yet in wise old Ravenclaw, If you've a ready mind, Where those of wit and learning, Will always find their kind. " +
    "Or perhaps in Slytherin, You'll make your true friends, Those cunning folk use any means, To achieve their ends. " +
    "So put me on! Don't be afraid! And don't get in a flap! You're in safe hands (though I have none), For I'm a Thinking Cap! ",

    "sorting song 2. ",
    "sorting song 3. "
  ]

};
